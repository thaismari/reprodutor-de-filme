let campoIdade;
let campoFantasia;
let checkboxAcao;
let checkboxAventura;
let checkboxTerror;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  createElement("br");
  createSpan("Gosta de fantasia?");
  campoFantasia = createCheckbox();
  createElement("br");
  
  createSpan("Gosta de ação?");
  checkboxAcao = createCheckbox();
  createElement("br");
  
  createSpan("Gosta de aventura?");
  checkboxAventura = createCheckbox();
  createElement("br");
  
  createSpan("Gosta de terror?");
  checkboxTerror = createCheckbox();
}

function draw() {
  background("white");
  let idade = parseInt(campoIdade.value());
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAcao = checkboxAcao.checked();
  let gostaDeAventura = checkboxAventura.checked();
  let gostaDeTerror = checkboxTerror.checked();

  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAcao, gostaDeAventura, gostaDeTerror);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAcao, gostaDeAventura, gostaDeTerror) {
  // Exemplo de lógica simples para recomendar filmes com base nos gêneros
  if (idade < 10) {
    if (gostaDeFantasia) {
      return "A viagem de Chihiro";
    } else {
      return "O feitiço do tempo";
    }
  } else {
    // Para maiores de 10 anos
    if (gostaDeTerror) {
      return "Atividade paranormal";
    } else if (gostaDeAcao && gostaDeAventura) {
      return "Velozes e Furiosos";
    } else if (gostaDeAcao) {
      return "Missão Impossível";
    } else if (gostaDeAventura) {
      return "Indiana Jones";
    } else if (gostaDeFantasia) {
      return "Senhor dos Anéis";
    } else {
      return "O menino que descobriu o vento";
    }
  }
}
